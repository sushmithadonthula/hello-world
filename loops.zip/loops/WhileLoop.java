package com.combino.loops;

public class WhileLoop {
    int i=20;

    public void whileLoopTrial(){
        while(i>10){
            System.out.println(i);
            i--;
        }
    }

    public void doWhileLoopTrial(){
        do{
            System.out.println(i);
            i--;
        }while(i>5);
    }
}
