package com.combino.loops;

public class ForLoop {
    String[] cities={"England","Hyderabad","Warangal","New York","LA"}; //array

    public void forLoopTrial(){
        for(int i=0;i<cities.length;i++){
            System.out.println(cities[i]);
        }

    }

    public void forEachLoopTrial(){
        for(String city: cities){
            System.out.println(city);
        }
    }
}
