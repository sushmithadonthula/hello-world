package com.combino.loops;

public class Tester {
    public static void main(String[] args) {
        ForLoop forLoop=new ForLoop();
        forLoop.forLoopTrial();
        forLoop.forEachLoopTrial();

        System.out.println("While---------");
        WhileLoop whileLoop=new WhileLoop();
        whileLoop.whileLoopTrial();
        whileLoop.doWhileLoopTrial();
    }
}
